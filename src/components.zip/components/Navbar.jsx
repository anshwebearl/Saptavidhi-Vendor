import React, { useState, useEffect, useRef } from 'react';
import { FaCaretDown, FaCaretUp, FaBars } from 'react-icons/fa';
import logo from "../assets/images/logo.png";

const Navbar = () => {
    const [isServicesDropdownOpen, setIsServicesDropdownOpen] = useState(false);
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const servicesDropdownRef = useRef(null);
    const dropdownRef = useRef(null);

    const toggleServicesDropdown = () => {
        setIsServicesDropdownOpen(!isServicesDropdownOpen);
    };

    const toggleDropdown = () => {
        setIsDropdownOpen(!isDropdownOpen);
    };

    const toggleMobileMenu = () => {
        setIsMobileMenuOpen(!isMobileMenuOpen);
    };

    const handleClickOutside = (event) => {
        if (servicesDropdownRef.current && !servicesDropdownRef.current.contains(event.target)) {
            setIsServicesDropdownOpen(false);
        }
        if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
            setIsDropdownOpen(false);
        }
    };

    useEffect(() => {
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    return (
        <header className="bg-transparent m-auto py-2 flex flex-row justify-between items-center px-4 md:px-8">
            <div className="w-[100px] md:w-[150px] bg-cover mr-4 md:mr-8">
                <img src={logo} alt="Logo" style={{ width: '100%', height: 'auto' }} />
            </div>
            <button
                className="md:hidden text-2xl"
                onClick={toggleMobileMenu}
            >
                <FaBars />
            </button>
            <div className={`fixed inset-0 bg-black bg-opacity-50 z-40 ${isMobileMenuOpen ? 'block' : 'hidden'} md:hidden`} onClick={toggleMobileMenu}></div>
            <nav className={`fixed top-0 right-0 h-full bg-white z-50 ${isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'} transition-transform duration-300 md:relative md:transform-none md:flex md:items-center`}>
                <div className="flex flex-col md:flex-row md:items-center h-full md:h-auto">
                    <div href="#" className="font-poppins font-medium text-[16px] leading-[24px] mr-8 p-4 md:p-0">Home</div>
                    <div href="#" className="font-poppins font-medium text-[16px] leading-[24px] mr-8 p-4 md:p-0">Create a Wedding</div>
                    <div className="relative font-poppins font-medium text-[16px] leading-[24px] mr-8 p-4 md:p-0">
                        <button onClick={toggleServicesDropdown} className="flex items-center">
                            Services {isServicesDropdownOpen ? <FaCaretUp className="ml-2 text-[#CF166F]" /> : <FaCaretDown className="ml-2 text-[#CF166F]" />}
                        </button>
                        {isServicesDropdownOpen && (
                            <div ref={servicesDropdownRef} className="absolute top-full mt-2 bg-white rounded-[30px] p-6 shadow-lg w-[200px] z-50">
                                <div className="mb-4 font-poppins font-medium text-[16px] leading-[24px]">Service 1</div>
                                <div className="mb-4 font-poppins font-medium text-[16px] leading-[24px]">Service 2</div>
                                <div className="mb-4 font-poppins font-medium text-[16px] leading-[24px]">Service 3</div>
                                <div className="mb-4 font-poppins font-medium text-[16px] leading-[24px]">Service 4</div>
                            </div>
                        )}
                    </div>
                    <div href="#" className="font-poppins font-medium text-[16px] leading-[24px] mr-8 p-4 md:p-0">Our Plans</div>
                    <div href="#" className="font-poppins font-medium text-[16px] leading-[24px] mr-8 p-4 md:p-0">Contact Us</div>
                    <div className="relative flex flex-col p-4 md:p-0">
                        <button onClick={toggleDropdown} className="flex items-center font-poppins font-medium text-[16px] leading-[24px] text-[#CF166F]">
                            Saathi R. {isDropdownOpen ? <FaCaretUp className="ml-2 text-[#CF166F]" /> : <FaCaretDown className="ml-2 text-[#CF166F]" />}
                        </button>
                        {isDropdownOpen && (
                            <div ref={dropdownRef} className="absolute top-full mt-2 bg-white rounded-[30px] p-6 shadow-lg w-[150px] z-50">
                                <div className="mb-4 font-poppins font-medium text-[16px] leading-[24px]">Saathi Rathod</div>
                                <div className="mb-4 font-poppins font-medium text-[16px] leading-[24px]">Saathi Rathod</div>
                                <div className="mb-4 font-poppins font-medium text-[16px] leading-[24px]">Saathi Rathod</div>
                                <div className="mb-4 font-poppins font-medium text-[16px] leading-[24px]">Saathi Rathod</div>
                            </div>
                        )}
                    </div>
                </div>
            </nav>
        </header>
    );
};

export default Navbar;
