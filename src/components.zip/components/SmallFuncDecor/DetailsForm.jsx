// import React from 'react';

// const DetailsForm = () => {
//   return (
//     <div className="relative h-64 sm:h-80 md:h-96 lg:h-[600px] w-full">
//     <div className="absolute inset-0 bg-[url('/SmallFuncDecor.jpg')] bg-cover bg-center"></div>
//     <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black"></div>


//     // form div starts here
//     <div className="bg-white p-4 md:p-6 rounded-2xl shadow-md max-w-md mx-auto font-poppins ">
//       <h1 className="text-center text-xl md:text-2xl font-semibold mb-4">Please Share Your Details</h1>
//       <hr className="mb-6 border-gray-300" />

//       <form>
//         <label className="block text-black mb-2 text-left">Full Name</label>
//         <input
//           type="text"
//           placeholder='Enter Full Name'
//           className="w-full p-2 mb-4 border rounded-xl border-[#FF8DA6] focus:outline-none"
//         />

//         <label className="block text-black mb-2 text-left">Mobile No.</label>
//         <input
//           type="text"
//           placeholder='Enter Mobile No.'
//           className="w-full p-2 mb-4 border rounded-xl border-[#FF8DA6] focus:outline-none"
//         />

//         <label className="block text-black mb-2 text-left">Email</label>
//         <input
//           type="email"
//           placeholder='Enter Email'
//           className="w-full p-2 mb-4 border rounded-xl border-[#FF8DA6] focus:outline-none"
//         />

//         <label className="block text-black mb-2 text-left">Function Date</label>
//         <input
//           type="date"
//           placeholder='Select Date'
//           className="w-full p-2 mb-4 border rounded-xl border-[#FF8DA6] focus:outline-none"
//         />

//         <label className="block text-black mb-2 text-left">Choose Event</label>
//         <select
//           placeholder='Choose Event'
//           className="w-full p-2 mb-4 border rounded-xl border-[#FF8DA6] focus:outline-none"
//         >
//           <option>Event 1</option>
//           <option>Event 2</option>
//           <option>Event 3</option>
//         </select>

//         <button
//           type="submit"
//           className="w-full py-2 rounded-lg text-white bg-gradient-to-r from-[#FF8DA6] to-[#c2bfc1] focus:outline-none"
//         >
//           Submit
//         </button>
//       </form>
//     </div>
// // forms div ends here
// </div>
// //


//   );
// };

// export default DetailsForm;









// import React from 'react';

// const DetailsForm = () => {
//   return (
//     <div className="relative h-64 sm:h-80 md:h-96 lg:h-[600px] w-full flex-wrap">
  
//       <div className="absolute inset-0 bg-[url('/SmallFuncDecor.jpg')] bg-cover bg-center"></div>

//       <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black"></div>

  

//       {/* Form container */}
//       <div className="relative  flex items-center justify-end pr-4 md:pr-8 lg:pr-12  ">
//         <div className="bg-white p-4 md:p-6 rounded-2xl shadow-md max-w-xs md:max-w-sm w-full font-poppins">
//           <h1 className="text-center text-xl md:text-2xl font-semibold mb-4">Please Share Your Details</h1>
//           <hr className="mb-6 border-gray-300" />

//           <form>
//             <label className="block text-black mb-2 text-left">Full Name</label>
//             <input
//               type="text"
//               placeholder="Enter Full Name"
//               className="w-full p-2 mb-4 border rounded-xl border-[#FF8DA6] focus:outline-none"
//             />

//             <label className="block text-black mb-2 text-left">Mobile No.</label>
//             <input
//               type="text"
//               placeholder="Enter Mobile No."
//               className="w-full p-2 mb-4 border rounded-xl border-[#FF8DA6] focus:outline-none"
//             />

//             <label className="block text-black mb-2 text-left">Email</label>
//             <input
//               type="email"
//               placeholder="Enter Email"
//               className="w-full p-2 mb-4 border rounded-xl border-[#FF8DA6] focus:outline-none"
//             />

//             <label className="block text-black mb-2 text-left">Function Date</label>
//             <input
//               type="date"
//               placeholder="Select Date"
//               className="w-full p-2 mb-4 border rounded-xl border-[#FF8DA6] focus:outline-none"
//             />

//             <label className="block text-black mb-2 text-left">Choose Event</label>
//             <select
//               className="w-full p-2 mb-4 border rounded-xl border-[#FF8DA6] focus:outline-none"
//             >
//               <option>Event 1</option>
//               <option>Event 2</option>
//               <option>Event 3</option>
//             </select>

//             <button
//               type="submit"
//               className="w-full py-2 rounded-lg text-white bg-gradient-to-r from-[#FF8DA6] to-[#c2bfc1] focus:outline-none"
//             >
//               Submit
//             </button>
//           </form>
//         </div>
//       </div>
//     </div>
   
//   );
// };

// export default DetailsForm;









// 




import React from 'react';

const DetailsForm = () => {
  return (
    <div className="relative h-auto w-full flex-wrap">
      {/* Background image section */}
      <div className="relative h-64 sm:h-80 md:h-96 lg:h-[600px] w-full flex-wrap">
        <div className="absolute inset-0 bg-[url('/SmallFuncDecor.jpg')] bg-cover bg-center"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black"></div>

        <div className="absolute w-full h-full px-8 md:px-24 flex items-center">
          <div className="flex justify-center w-full items-center flex-wrap md:justify-between gap-10">
            <div className="flex flex-col gap-6 text-white max-w-lg">
              <p className="font-bold text-4xl">
                Decorate your intimate event with <span className='text-[#F97096]'>SaptaVidhi</span>
              </p>
              <p className="font-medium text-xl">
                Haldi, mehendi, or engagement decor for under 100 guests
              </p>
              <table className="w-full">
                <tbody>
                  <tr>
                    <td><img src="/Vector.png" alt="Point Image" className="h-6 w-6" /></td>
                    <td>Decor starting at INR 30,000 only</td>
                    <td><img src="/Vector.png" alt="Point Image" className="h-6 w-6" /></td>
                    <td>Customizable Decor</td>
                  </tr>
                  <tr>
                    <td><img src="/Vector.png" alt="Point Image" className="h-6 w-6 space-x-4" /></td>
                    <td>Hygiene and Safety Compliant Team</td>
                    <td><img src="/Vector.png" alt="Point Image" className="h-6 w-6 space-x-20" /></td>
                    <td>Hassle free decor at your doorstep</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="relative flex items-center justify-end pr-4 md:pr-8 lg:pr-12 h-">
              <div className="bg-white p-4 md:p-6 rounded-2xl shadow-md max-w-xs md:max-w-sm w-full font-poppins text-[8px] ">
                <h1 className="text-center text-xl md:text-2xl font-semibold mb-4">Please Share Your Details</h1>
                <hr className="mb-6 border-gray-300" />

                <form>
                  <label className="block text-black mb-2 text-left">Full Name</label>
                  <input
                    type="text"
                    placeholder="Enter Full Name"
                    className="w-full p-2 mb-4 border rounded-xl border-[#FF8DA6] focus:outline-none"
                  />

                  <label className="block text-black mb-2 text-left">Mobile No.</label>
                  <input
                    type="text"
                    placeholder="Enter Mobile No."
                    className="w-full p-2 mb-4 border rounded-xl border-[#FF8DA6] focus:outline-none"
                  />

                  <label className="block text-black mb-2 text-left">Email</label>
                  <input
                    type="email"
                    placeholder="Enter Email"
                    className="w-full p-2 mb-4 border rounded-xl border-[#FF8DA6] focus:outline-none"
                  />

                  <label className="block text-black mb-2 text-left">Function Date</label>
                  <input
                    type="date"
                    placeholder="Select Date"
                    className="w-full p-2 mb-4 border rounded-xl border-[#FF8DA6] focus:outline-none"
                  />

                  <label className="block text-black mb-2 text-left">Choose Event</label>
                  <select
                    className="w-full p-2 mb-4 border rounded-xl border-[#FF8DA6] focus:outline-none"
                  >
                    <option>Event 1</option>
                    <option>Event 2</option>
                    <option>Event 3</option>
                  </select>

                  <button
                    type="submit"
                    className="w-full py-2 rounded-lg text-white bg-gradient-to-r from-[#FF8DA6] to-[#c2bfc1] focus:outline-none"
                  >
                    Submit
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* New Design Sections */}
      <div className="bg-white py-10">
        {/* Latest Work Section */}
        <div className="px-8 md:px-24">
          <h2 className="text-2xl font-bold mb-4">See our latest work</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {/* Replace with your images */}
            <img src="/image1.jpg" alt="Work 1" className="w-full h-40 object-cover rounded-lg" />
            <img src="/image2.jpg" alt="Work 2" className="w-full h-40 object-cover rounded-lg" />
            <img src="/image3.jpg" alt="Work 3" className="w-full h-40 object-cover rounded-lg" />
            <img src="/image4.jpg" alt="Work 4" className="w-full h-40 object-cover rounded-lg" />
            <img src="/image5.jpg" alt="Work 5" className="w-full h-40 object-cover rounded-lg" />
            <img src="/image6.jpg" alt="Work 6" className="w-full h-40 object-cover rounded-lg" />
            <img src="/image7.jpg" alt="Work 7" className="w-full h-40 object-cover rounded-lg" />
            <img src="/image8.jpg" alt="Work 8" className="w-full h-40 object-cover rounded-lg" />
            <img src="/image9.jpg" alt="Work 9" className="w-full h-40 object-cover rounded-lg" />
            <img src="/image10.jpg" alt="Work 10" className="w-full h-40 object-cover rounded-lg" />
            <img src="/image11.jpg" alt="Work 11" className="w-full h-40 object-cover rounded-lg" />
            <img src="/image12.jpg" alt="Work 12" className="w-full h-40 object-cover rounded-lg" />
          </div>
          <button className="mt-4 p-2 bg-pink-500 text-white rounded-lg">View All</button>
        </div>

        {/* Event Category Tabs */}
        <div className="mt-10 px-8 md:px-24">
          <div className="flex space-x-4">
            <button className="py-2 px-4 bg-pink-500 text-white rounded-lg">Haldi & Mehendi</button>
            <button className="py-2 px-4 bg-gray-200 text-gray-700 rounded-lg">Rooka/Engagement</button>
          </div>
        </div>

        {/* Reviews Section */}
        <div className="mt-10 px-8 md:px-24">
          <h2 className="text-2xl font-bold mb-4">Reviews</h2>
          <div className="space-y-4">
            <div className="p-4 bg-gray-100 rounded-lg">
              <div className="flex items-center space-x-4">
                <img src="/user1.jpg" alt="User 1" className="h-12 w-12 rounded-full" />
                <div>
                  <p className="font-bold">Saathii</p>
                  <p className="text-gray-600">18 June, 2020</p>
                </div>
              </div>
              <p className="mt-4">We had booked for our House function decor and they had done a fantastic job. They were so understanding of our requirements and fulfilled all our expectations...</p>
              <button className="text-pink-500 mt-2">Read More</button>
            </div>
            <div className="p-4 bg-gray-100 rounded-lg">
              <div className="flex items-center space-x-4">
                <img src="/user2.jpg" alt="User 2" className="h-12 w-12 rounded-full" />
                <div>
                  <p className="font-bold">Saathii</p>
                  <p className="text-gray-600">18 June, 2020</p>
                </div>
              </div>
              <p className="mt-4">We had booked for our House function decor and they had done a fantastic job. They were so understanding of our requirements and fulfilled all our expectations...</p>
              <button className="text-pink-500 mt-2">Read More</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DetailsForm;

